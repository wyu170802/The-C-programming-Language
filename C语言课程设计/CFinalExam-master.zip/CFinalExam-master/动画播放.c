/*
���Ŷ�����ʱ��������
*/

/*
�Ż�����ʹ������ø�����
*/


#include <stdio.h>
#include <stdlib.h>
#include <Windows.h>

#define SIZE          7399                                //һ֡ͼƬ�Ĵ�С
#define START_COUNT   19
#define PRINT_COUNT   37
#define END_COUNT     43
#define TIME          30                                  //�ȴ�ʱ��

void av(void)
{
	system("mode con:cols=150 lines=49");

	printf("\n\n\n\n                                                           �벻Ҫ�����������̨");
	
	int count;
	FILE * file;                                      //��Ƶ�ļ�
	//char ch[99][SIZE];
	char ch[SIZE];
	char filename[50] = "zhen1\\00.txt";
	Sleep(2000);
	int n;
	int j = 1;
	int i = 0;

	//while (i < 19)
	//{
	//	n = j / 10;
	//	filename[29] = n + '0';
	//	filename[30] = j % 10 + '0';
	//	file = fopen(filename, "r");
	//	fread(ch[i], sizeof(char), SIZE, file);
	//	ch[i][7398] = '\0';
	//	fclose(file);
	//	++i;
	//	++j;
	//}

	//j = 1;
	//filename[27] = '2';
	//
	//while (i < 56)
	//{
	//	n = j / 10;
	//	filename[29] = n + '0';
	//	filename[30] = j % 10 + '0';
	//	file = fopen(filename, "r");
	//	fread(ch[i], sizeof(char), SIZE, file);
	//	ch[i][7398] = '\0';
	//	fclose(file);
	//	++i;
	//	++j;
	//}

	//filename[27] = '3';
	//j = 1;

	//while (i < 99)
	//{
	//	n = j / 10;
	//	filename[29] = n + '0';
	//	filename[30] = j % 10 + '0';
	//	file = fopen(filename, "r");
	//	fread(ch[i], sizeof(char), SIZE, file);
	//	ch[i][7398] = '\0';
	//	fclose(file);
	//	++i;
	//	++j;
	//}

	//for (i = 0; i < 55; ++i)
	//{
	//	system("cls");
	//	puts(ch[i]);
	//	Sleep(TIME);
	//}

	//Sleep(1000);
	//while (i < 99)
	//{
	//	puts(ch[i]);
	//	Sleep(TIME);
	//	system("cls");
	//	++i;
	//}





	for (i = 1; i <= 3; i++)
	{
		if (i == 1)
		{
			count = START_COUNT;
		}
		else if (i == 2)
		{
			count = PRINT_COUNT;
		}
		else
		{
			count = END_COUNT;
		}

		filename[4] = i + '0';
		
		filename[6] = '0';
		for (j = 1; j <= count; j++)
		{
			n = j / 10;
			filename[6] = n + '0';
			filename[7] = j % 10 + '0';

			file = fopen(filename, "r");

			fread(ch, sizeof(char), SIZE, file);
			ch[7398] = '\0';
			puts(ch);

			fclose(file);
			Sleep(TIME);
			if (j != count)
			{
				system("cls");
			}
		}
		if (i == 2)
			Sleep(1000);
	}

	system("cls");
	Sleep(1000);
}