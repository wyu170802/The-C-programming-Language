#include "1.h"
#include "keyboard.h"

void shudu()
{
	while (1)
	{
		system("cls");
		int b;
		int a[9][9];
		HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
		if (hConsole != NULL)
		{
			SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), FOREGROUND_GREEN | FOREGROUND_RED | FOREGROUND_BLUE);
			printf("\n\n\n\t\t\t\t___________________________________________________\n\n\n");
			SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), FOREGROUND_INTENSITY | FOREGROUND_GREEN | FOREGROUND_BLUE);
			printf("\t\t\t\t\t\t   ����������     \n\n\n");
			printf("\t\t\t\t\t*  1.�ֶ�������Ŀ��ֱ�ӽ��⡣      *\n");
			printf("\t\t\t\t\t*  2.�½�һ���ļ�������Ŀ���ȥ��  *\n");
			printf("\t\t\t\t\t*  3.�������ļ��ж�ȡ��Ŀ����⡣  *\n");
			printf("\t\t\t\t\t*  4.�������                      *\n");
			printf("\t\t\t\t\t*  ESC.�˳���                        *\n");
			SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), FOREGROUND_GREEN | FOREGROUND_RED | FOREGROUND_BLUE);
		}
		printf("\n\n\n\t\t\t\t____________________________________________________\n\n");
		b = getch();
		system("cls");
		switch (b)
		{
		case VK_ESC:
			return;
		case VK_1_OR_NUM_1:
		{
			if (input(a))
				solve(a);
			break;
		}
		case VK_2_OR_NUM_2:
		{
			build(a);
			break;
		}
		case VK_3_OR_NUM_3: {
			read(a);
			break;
		}
		case VK_4_OR_NUM_4: {
			question_bank();
			break;
		}
		default:
		{
			printf("�����ѡ����Ч��\n");
			Sleep(3000);
		}
		}
		system("pause");
	}
	system("pause");
}

void build(int(*a)[9])
{
	FILE *fp;
	if ((fp = fopen("b.txt", "wb+")) == NULL)
	{
		printf("��ӡ�ļ�ʧ��\n");
		system("pause");
		return;
	}
	printf("����������������\n");
	for (int i = 0; i < 9; i++)
	{
		for (int j = 0; j < 9; j++)
		{ 
			scanf("%d", &a[i][j]);
			fprintf(fp,"%d ",a[i][j]);
		}
	}
	fclose(fp);
}

void read(int(*a)[9])//���ļ������ļ��л�ȡ�����⣬�ر��ļ�
{	
	
	char ch,filename[20];
	printf("�������������ļ���(���磺b.txt)��\n");
	scanf("%s", &filename);
	FILE *fp = fopen(filename, "rb+");
	if (fp == NULL)
	{
		printf("���ļ�ʧ�ܡ�\n");
		system("pause");
		return;
	}
	ch = fgetc(fp);
	if (ch == EOF)
	{
		printf("���ļ���û�������⣬��Ҫ�����Ŀ���ܲ��ڸ��ļ���뷵��Ŀ¼���²�����\n");
	}
	else
	{
		for (int i = 0; i < 9; i++)
		{
			for (int j = 0; j < 9; j++)
			{
				fscanf(fp, "%d", &a[i][j]);
			}
		}
		system("cls");
		/*for (int i = 0; i < 9; i++)
		{
			for (int j = 0; j < 9; j++)
			{
				printf("%d ", a[i][j]);
			}
			printf("\n");
		}*/
		output_1(a);
		fclose(fp);
		printf("�鿴������");
		system("pause");
		solve(a);
	}
}

void solve(int(*a)[9])
{
	system("cls");
	if (find(0, a))
		output_2(a);                       
	else
		printf("������û�н����\n");
}

int input(int(*a)[9])                // a��ָ��������������ɵ������ָ��  
{
	int i, j;
	printf("�ӵ�һ�е�һ�п�ʼ��������ÿһ�����ݣ�Ҫ���������0��\n");//\n����
	for (i = 0; i < 9; i++)
	{
		printf("�������%d�У�", i + 1);
		for (j = 0; j < 9; j++)
		{
			while (scanf("%d", &a[i][j]) != 1)
			{
				printf("��������������������\n");
				--i;
				j = 9;
				while (getchar() != '\n')
					continue;
				break;
			}
		}
		
	}
	for (i = 0; i < 9; i++)
	{
		for (j = 0; j < 9; j++)
		{
			if (a[i][j] == 0)
				break;
			else
				continue;
		}
	}
	if (i == 9 && j == 9)
	{
		printf("�������޽�\n");
		return 0;
	}
	return 1;
}

void output_1(int(*a)[9])//���ԭ��
{
	system("cls");
	int i, j;
	HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
	if (hConsole != NULL)
	{
		for (i = 0; i < 9; i++)
		{
			for (j = 0; j < 9; j++)
			{
				if (a[i][j] != 0)
				{
					SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), FOREGROUND_INTENSITY | FOREGROUND_GREEN);
					printf("%d   ", a[i][j]);
				}
				else
				{
					SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), FOREGROUND_INTENSITY | FOREGROUND_GREEN | FOREGROUND_RED | FOREGROUND_BLUE);
					printf("%d   ", a[i][j]);
				}
				if (j % 3 == 2)
					printf("\t");

			}
			printf("\n");
			if (i % 3 == 2)
				printf("\n");
		}
	}
}

int rule(int x, int y, int i, int(*a)[9])
{
	int c, r;
	for (c = 0; c < 9; c++)
	{
		if (c != y&&a[x][c] == i)
			return 0;
	}
	for (r = 0; r < 9; r++)
	{
		if (r != x&&a[r][y] == i)
			return 0;
	}
	for (r = x / 3 * 3; r< x / 3 * 3 + 3; r++)
	{
		for (c = y / 3 * 3; c < y / 3 * 3 + 3; c++)
		{
			if (a[r][c] == i && r != x&&c != y)
				return 0;
		}
	}
	return 1;
}

int find(int num, int(*a)[9])
{
	int x, y;
	x = num / 9;
	y = num % 9;
	if (num >= 81)
		return 1;
	if (a[x][y] != 0)
	{
		return find(num + 1, a);
	}
	else
	{
		for (int i = 1; i <= 9; i++)
		{

			if (rule(x, y, i, a))
			{
				a[x][y] = i;
				if (find(num + 1, a))
					return 1;
			}
			a[x][y] = 0;
		}
		return 0;
	}

}

void output_2(int(*a)[9])//������
{
	system("cls");
	int i, j;
	for (i = 0; i < 9; i++)
	{
		for (j = 0; j < 9; j++)
		{
			system("color 0B");
			printf("%d   ", a[i][j]);
			if (j % 3 == 2)
				printf("\t");
		}
		printf("\n");
		if (i % 3 == 2)
			printf("\n");
	}
}

void question_bank()
{
	int a, b,e;
	do {
		printf("\n\n\n\n\t\t\t\t��ѡ����Ŀ���ɷ�ʽ��\n\n");
		printf("\t\t\t\t1.��ѡһ����������һ����Ŀ��\n");
		printf("\t\t\t\t2.�������һ����Ŀ��\n");
		b = getch();
		if (b == VK_1_OR_NUM_1)
		{
			printf("������һ�����֣�1--10��\n");
			scanf("%d", &a);
		}
		else if(b==VK_2_OR_NUM_2)
		{
			system("cls");
			int t = 0, d = 11;
			srand((unsigned int)time(NULL)); /*��ʼ�����������*/
			a = rand() % (d - t) + t; /*����һ��[t,d)�����ڵ�����*/
			printf("%d\n", a);
			Sleep(2000);
		}
		else
		{
			system("cls");
			printf("��������\n");
			Sleep(2000);
			return;
		}
		system("cls");
		switch (a)
		{
		case 0:
			return;
		case 1:
		{
			printf("\n\n\n\n");
			system("color 0A");
			printf("\t\t\t\t1 0 0 0 0 7 0 9 0 \n");
			printf("\t\t\t\t0 3 0 0 2 0 0 0 8 \n");
			printf("\t\t\t\t0 0 9 6 0 0 5 0 0 \n");
			printf("\t\t\t\t0 0 5 3 0 0 9 0 0 \n");
			printf("\t\t\t\t0 1 0 0 8 0 0 0 2 \n");
			printf("\t\t\t\t6 0 0 0 0 4 0 0 0 \n");
			printf("\t\t\t\t3 0 0 0 0 0 0 1 0 \n");
			printf("\t\t\t\t0 4 0 0 0 0 0 0 7 \n");
			printf("\t\t\t\t0 0 7 0 0 0 3 0 0 \n\n\n\n\n\n\n\n\n\n\n\n");
			break;
		}
		case 2:
		{
			printf("\n\n\n\n");
			system("color 0B");
			printf("\t\t\t\t2 8 0 7 6 0 0 0 0 \n");
			printf("\t\t\t\t0 0 0 0 0 0 0 0 0 \n");
			printf("\t\t\t\t0 0 4 5 0 0 0 3 0 \n");
			printf("\t\t\t\t8 0 1 0 0 6 0 9 0 \n");
			printf("\t\t\t\t0 4 0 0 3 0 0 7 0 \n");
			printf("\t\t\t\t0 9 0 4 0 0 1 0 6 \n");
			printf("\t\t\t\t0 6 0 0 0 9 2 0 0 \n");
			printf("\t\t\t\t0 0 0 0 0 0 0 0 0 \n");
			printf("\t\t\t\t0 0 0 0 5 3 0 6 8 \n\n\n\n\n\n\n\n\n\n\n\n");
			break;
		}
		case 3: {
			printf("\n\n\n\n");
			system("color 0C");
			printf("\t\t\t\t0 6 1 0 3 0 0 2 0 \n");
			printf("\t\t\t\t0 5 0 0 0 8 1 0 7 \n");
			printf("\t\t\t\t0 0 0 0 0 7 0 3 4 \n");
			printf("\t\t\t\t0 0 9 0 0 6 3 7 8 \n");
			printf("\t\t\t\t0 0 3 2 7 9 5 0 0 \n");
			printf("\t\t\t\t5 7 0 3 0 0 9 0 2 \n");
			printf("\t\t\t\t1 9 0 7 6 0 0 0 0 \n");
			printf("\t\t\t\t8 0 2 4 0 0 7 6 0 \n");
			printf("\t\t\t\t6 4 0 0 1 0 2 5 0 \n\n\n\n\n\n\n\n\n\n\n\n");
			break;
		}
		case 4: {
			printf("\n\n\n\n");
			system("color 0D");
			printf("\t\t\t\t1 0 0 8 3 0 0 0 2 \n");
			printf("\t\t\t\t5 7 0 0 0 1 0 0 0 \n");
			printf("\t\t\t\t0 0 0 5 0 9 0 6 4 \n");
			printf("\t\t\t\t7 0 4 0 0 8 5 9 0 \n");
			printf("\t\t\t\t0 0 3 0 1 0 4 0 0 \n");
			printf("\t\t\t\t0 5 1 4 0 0 3 0 6 \n");
			printf("\t\t\t\t3 6 0 7 0 4 0 0 0 \n");
			printf("\t\t\t\t0 0 0 6 0 0 0 7 9 \n");
			printf("\t\t\t\t8 0 0 0 5 2 0 0 3 \n\n\n\n\n\n\n\n\n\n\n\n");
			break;
		}
		case 5: {
			printf("\n\n\n\n");
			system("color 0E");
			printf("\t\t\t\t0 3 0 0 0 7 0 0 4 \n");
			printf("\t\t\t\t6 0 2 0 4 1 0 0 0 \n");
			printf("\t\t\t\t0 5 0 0 3 0 9 6 7 \n");
			printf("\t\t\t\t0 4 0 0 0 3 0 0 6 \n");
			printf("\t\t\t\t0 8 7 0 0 0 3 5 0 \n");
			printf("\t\t\t\t9 0 0 7 0 0 0 2 0 \n");
			printf("\t\t\t\t7 1 8 0 2 0 0 4 0 \n");
			printf("\t\t\t\t0 0 0 1 6 0 8 0 9 \n");
			printf("\t\t\t\t4 0 0 5 0 0 0 3 0 \n\n\n\n\n\n\n\n\n\n\n\n");
			break;
		}
		case 6: {
			printf("\n\n\n\n");
			system("color 03");
			printf("\t\t\t\t0 8 5 0 0 0 2 1 0 \n");
			printf("\t\t\t\t0 0 0 3 0 0 7 0 4 \n");
			printf("\t\t\t\t5 0 3 4 0 9 0 0 0 \n");
			printf("\t\t\t\t0 4 0 2 0 6 0 3 0 \n");
			printf("\t\t\t\t0 0 0 1 0 3 9 0 7 \n");
			printf("\t\t\t\t6 0 8 0 0 5 0 0 0 \n");
			printf("\t\t\t\t1 0 0 8 4 0 3 6 0 \n");
			printf("\t\t\t\t0 2 7 0 0 0 8 9 0 \n\n\n\n\n\n\n\n\n\n\n\n");
			break;
		}
		case 7: {
			printf("\n\n\n\n");
			system("color 04");
			printf("\t\t\t\t0 8 0 0 0 1 6 0 0 \n");
			printf("\t\t\t\t0 7 0 4 0 0 0 2 1 \n");
			printf("\t\t\t\t5 0 0 3 9 6 0 0 0 \n");
			printf("\t\t\t\t2 0 4 0 5 0 1 3 0 \n");
			printf("\t\t\t\t0 0 8 9 0 7 5 0 0 \n");
			printf("\t\t\t\t0 5 7 0 3 0 9 0 0 \n");
			printf("\t\t\t\t0 0 0 5 6 3 0 0 9 \n");
			printf("\t\t\t\t3 1 0 0 0 2 0 5 0 \n");
			printf("\t\t\t\t0 0 5 8 0 0 0 4 0 \n\n\n\n\n\n\n\n\n\n\n\n");
			break;
		}
		case 8: {
			printf("\n\n\n\n");
			system("color 05");
			printf("\t\t\t\t0 1 2 6 8 0 0 9 0 \n");
			printf("\t\t\t\t6 0 0 0 0 4 0 1 0 \n");
			printf("\t\t\t\t8 0 5 2 0 0 3 7 0 \n");
			printf("\t\t\t\t0 0 0 0 0 7 5 2 3 \n");
			printf("\t\t\t\t0 0 0 4 0 6 0 0 0 \n");
			printf("\t\t\t\t3 8 1 9 0 0 0 0 0 \n");
			printf("\t\t\t\t0 5 4 0 0 2 8 0 1 \n");
			printf("\t\t\t\t0 7 0 3 0 0 0 0 2 \n");
			printf("\t\t\t\t0 3 0 0 5 9 7 6 0 \n\n\n\n\n\n\n\n\n\n\n\n");
			break;
		}
		case 9: {
			printf("\n\n\n\n");
			system("color 06");
			printf("\t\t\t\t1 0 0 0 0 7 0 9 0 \n");
			printf("\t\t\t\t0 3 0 0 2 0 0 0 8 \n");
			printf("\t\t\t\t0 0 9 6 0 0 5 0 0 \n");
			printf("\t\t\t\t0 0 5 3 0 0 9 0 0 \n");
			printf("\t\t\t\t0 1 0 0 8 0 0 0 2 \n");
			printf("\t\t\t\t6 0 0 0 0 4 0 0 0 \n");
			printf("\t\t\t\t3 0 0 0 0 0 0 1 0 \n");
			printf("\t\t\t\t0 4 0 0 0 0 0 0 7 \n");
			printf("\t\t\t\t0 0 7 0 0 0 3 0 0 \n\n\n\n\n\n\n\n\n\n\n\n");
			break;
		}
		case 10: {
			printf("\n\n\n\n");
			system("color 02");
			printf("\t\t\t\t0 0 0 0 0 0 0 7 0 \n");
			printf("\t\t\t\t0 6 0 0 1 0 0 0 4 \n");
			printf("\t\t\t\t0 0 3 4 0 0 2 0 0 \n");
			printf("\t\t\t\t8 0 0 0 0 3 0 5 0 \n");
			printf("\t\t\t\t0 0 2 9 0 0 7 0 0 \n");
			printf("\t\t\t\t0 4 0 0 8 0 0 0 9 \n");
			printf("\t\t\t\t0 2 0 0 6 0 0 0 7 \n");
			printf("\t\t\t\t0 0 0 1 0 0 9 0 0 \n");
			printf("\t\t\t\t7 0 0 0 0 8 0 6 0 \n\n\n\n\n\n\n\n\n\n\n\n");
			break;
		}
		default:
		{
			printf("�����ѡ����Ч��\n");
			Sleep(3000);
			return;
		}
		}
		printf("�����밴1��\n");
		scanf("%d", &e);
		system("cls");
	}while (e == 1);
}