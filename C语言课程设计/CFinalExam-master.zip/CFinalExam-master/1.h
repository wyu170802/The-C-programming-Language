#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <Windows.h>
#include <conio.h>

void build(int(*a)[9]);
void read(int(*a)[9]);
void solve(int(*a)[9]);
int rule(int x, int y, int i, int(*a)[9]);
int find(int num, int(*a)[9]);      
int input(int(*a)[9]);
void output_1(int(*a)[9]);
void output_2(int(*a)[9]);
void question_bank();